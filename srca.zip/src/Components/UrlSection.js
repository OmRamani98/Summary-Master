// UrlSection.js
import React, { useState } from "react";
import Summary from "./Summary";
import InputUrl from './InputUrl';

const UrlSection = () => {
  return (
    <>
      <div className="relative">
        <InputUrl />
      </div>  
      
    </>
  );
};

export default UrlSection;
